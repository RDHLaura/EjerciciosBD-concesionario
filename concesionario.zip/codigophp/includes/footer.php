<footer>
  <p>Author: Laura Rodríguez de Haro</p>
  <p><a href="mailto:hege@example.com">hege@example.com</a></p>
</footer> 