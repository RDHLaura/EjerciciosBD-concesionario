<nav >                  
    <ul>
        <li><a href="listarCoches.php">Listado</a></li>
        <li><a href="insertarCoche.php">Insertar coche</a></li>
        <li><a href="listarClientes.php">Listar clientes</a></li>
    </ul>
</nav>   